﻿namespace Quartz.Web.Api.Dto
{
    public enum SchedulerStatus
    {
        Unknown = 0,
        Running = 1,
        Standby = 2,
        Shutdown = 3,
    }
}