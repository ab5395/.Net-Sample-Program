﻿export function configure(aurelia) {
    aurelia.globalResources("./date-format", "./duration-format");
}