﻿/*using System;
using Microsoft.AspNetCore.SignalR;

namespace Quartz.Web.LiveLog
{
    [CLSCompliant(false)]
    public class LiveLogHub : Hub
    {
    }
}
*/